import React, { Component } from 'react';
import CheckinStore from './CheckinStore.js'
import CheckinForm from './CheckinForm.js'

import {BrowserRouter as Router, Redirect, Link, NavLink} from "react-router-dom";
import {Route} from "react-router-dom/Route";



class CheckinPage extends React.Component {
   
 
  constructor(props){
    
    super(props)
     this.state={
        id_checkin:''
      }
      this.store= new CheckinStore()
      this.addCheckin=(checkin)=>{
          this.store.addCheckin(checkin) 
      }
      this.checkOut=(carNumber)=>{
          this.store.checkOut(carNumber) 
      }
     
     
  }
  
  componentDidMount(){
      this.store.emitter.addListener('ADD_CHECKIN_SUCCESS',()=>{
      console.log('Checkin added successfull');
      document.getElementById('checkInOut').textContent="Check out";
      

    })
     this.store.emitter.addListener('CHECKOUT_SUCCESS',()=>{
      console.log('Checkout successfull');
    })


    
  }
  render() {
    return (
        <div> 
           <CheckinForm addCheckin={this.addCheckin} checkOut={this.checkOut} />
        </div>
  
    );
  }
}
 


export default CheckinPage;