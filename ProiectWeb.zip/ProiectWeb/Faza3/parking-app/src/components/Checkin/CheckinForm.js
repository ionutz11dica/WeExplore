import React, { Component } from 'react';
import {Button} from 'react-bootstrap'

class CheckinForm extends Component {
  
  constructor(props){
      super(props)
      this.state={
          parkingname:'',
          carnumber:'',
          checkinAdded:false
      }
      
      this.handleOnClick=()=>{
        
        if(!this.state.checkinAdded){
        this.props.addCheckin({
        parkingname:this.state.parkingname,
        carnumber:this.state.carnumber
        })
         this.state.checkinAdded=true;
        document.getElementById("checkInOut").value="Check out"
        }
        else {
       
        this.props.checkOut(this.state.carnumber)
        this.state.checkinAdded=false;
        document.getElementById("checkInOut").value="Check in"
        }
     
      }

      this.handleChange=(evt)=>{
          this.setState({
              [evt.target.name]:evt.target.value
          })
      }
  }
  render() {
   
    return (
      <div id="checkin_div"> 

      <form id="checkin_f" >
      
       <input type="text" placeholder="Nume parcare" id="checkin_parking_address" name="parkingname" onChange={this.handleChange}/>
       <input type="text" placeholder="Numar masina" id="checkin_car_number" name="carnumber" onChange={this.handleChange}/>
       <Button bsStyle="primary" id="checkInOut" onClick={this.handleOnClick}>Check In </Button>
      
       </form> 
      </div>
    );
  }
}

export default CheckinForm;