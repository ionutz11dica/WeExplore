import React, { Component } from 'react';
import './MainPage.css'; 
import {Button} from 'react-bootstrap'
import CheckinPage from '../Checkin/CheckinPage'
import {BrowserRouter as Router, Redirect, Link, NavLink} from "react-router-dom";
import {Route} from "react-router-dom/Route";
import MapContainer from '../Map/Map'
import ParkingForm from '../Parking/ParkingForm'
const geolocation = require('geolocation')

class MainPage extends React.Component {
   
 
  constructor(props){
    
    super(props)
     
  }

 
  render() {
    return (
        <div id="main_page"> 
          <div id="chein_form">
              <CheckinPage/>
           </div>
        
           <div id="btn_add_car">
              <Button bsStyle="primary" id="go_to_add_car" name="go_to_add_car"  onClick={()=> {
                       document.getElementById("add-new-car-nav-link").click();
                      }} >Add a new car</Button>
              <NavLink id="add-new-car-nav-link" to="/addCar" exact activeStyle={
                {color: 'red'}
                }>Add car Page</NavLink>
           </div>

           <div id="div-map">
              <MapContainer id="container"/>
           </div>
           <div>
              <ParkingForm/>
           </div>
        </div>
      
    );
    
  }
}
 


export default MainPage;